

function add_comment_field(question,editable,callback){
    if( question.comment === undefined ) question.comment = {'text':""}
    let cText = document.createElement("textarea")
        cText.className = "form-control"
        cText.rows = 2
        cText.value = question.comment.text
        cText.placeholder = "Comments..."
        cText.disabled = !editable
        cText.oninput = function(){
            question.comment.text = cText.value
            if(callback) callback()
        }

    let cDiv = document.createElement("div")
        cDiv.className = "form-group"
        cDiv.appendChild(cText)

    return cDiv
}

function add_options(options,editable,callback){
    curDiv = document.createElement("div")
    optionName = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 12);
    options.forEach(option => {
        if (option.checked === undefined) option.checked = false
        optionId = Math.random().toString(36).replace(/[^a-z]+/g, '').substr(0, 12);

        let oInput = document.createElement("input")
        oInput.type = "radio"
        oInput.className = "custom-control-input"
        oInput.name = optionName
        oInput.id = optionId
        oInput.checked = option.checked
        oInput.disabled = !editable
        oInput.onchange = function () {
            options.forEach(o => o.checked = false)
            option.checked = oInput.checked
            if(callback) callback()
        }

        let oLabel = document.createElement("label")
        oLabel.className = "custom-control-label"
        oLabel.innerText = option.description
        oLabel.htmlFor = optionId

        let oDiv = document.createElement("div")
        oDiv.className = "custom-control custom-radio"
        oDiv.appendChild(oInput)
        oDiv.appendChild(oLabel)

        curDiv.appendChild(oDiv)
    })
    return curDiv
}

function add_review_category(category, editable,callback){

    let curDiv = document.createElement("div")

    let title = document.createElement("h3")
    title.innerText = category.title
    curDiv.appendChild(title)

    category.questions.forEach(question=>{
        let qTitle = document.createElement("h4")
        qTitle.innerText = question.title + ' - ' + question.description
        curDiv.appendChild(qTitle)

        if (question.options != null)
            curDiv.appendChild( add_options(question.options,editable,callback) )

        curDiv.appendChild( add_comment_field(question,editable,callback) )

    })

    return curDiv
}