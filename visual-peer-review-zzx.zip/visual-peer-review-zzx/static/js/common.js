

function load_cookies() {
    if (field1 = getCookie("netid")) document.getElementById("netid").value = field1.toLowerCase();
    if (field2 = getCookie("usfid")) document.getElementById("usfid").value = field2.toUpperCase();
}

function save_cookies(){
    document.getElementById("netid").value = document.getElementById("netid").value.toLowerCase()
    document.getElementById("usfid").value = document.getElementById("usfid").value.toUpperCase()

    setCookie("netid", document.getElementById("netid").value )
    setCookie("usfid", document.getElementById("usfid").value )
}

function get_netid(){ return document.getElementById("netid").value }
function get_usfid(){ return document.getElementById("usfid").value }
