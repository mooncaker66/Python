import os
import pathlib
from functools import wraps

import requests
from flask import Flask, session, abort, redirect, request, render_template
from google.oauth2 import id_token
from google_auth_oauthlib.flow import Flow
from pip._vendor import cachecontrol
import google.auth.transport.requests

from pymongo import MongoClient

conn = 'mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false'
client = MongoClient(conn)   #connect to the mongodb, I have a local one here, can change to other database if needed.

app = Flask("Google Login App")

#
app.secret_key = "secret_key"

os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1" #oauth requires the connection to be https, here just for testing purpose.

GOOGLE_CLIENT_ID = "151518700435-n3bpd8brubv5oeog2lvpqvsmjajeuq88.apps.googleusercontent.com"  # from google credential
client_secrets_file = os.path.join(pathlib.Path(__file__).parent, "client_secret.json")

# all the infromation how we want to authorize our users.
flow = Flow.from_client_secrets_file(
    client_secrets_file=client_secrets_file,
    # scopte is what API we would want google to return to us, we don't need any info, I just pass id, profile, email for testing.
    scopes=["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email",
            "openid"],
    redirect_uri="http://127.0.0.1:5000/callback" #the uri we went google to call back to.
)


# decorator that will check if the user is logged in.
def login_is_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "google_id" not in session:
            return abort(401)  # Authorization required
        else:
            return f(*args, **kwargs)

    return wrapper


# redirect users to google authentication page
@app.route("/login")
def login():
    authorization_url, state = flow.authorization_url()
    session["state"] = state  # check state we initially created and we received are the same.
    return redirect(authorization_url)


# receive data from google end point
@app.route("/callback")
def callback():
    flow.fetch_token(
        authorization_response=request.url)  # Completes the Authorization Flow and obtains an access token.

    if not session["state"] == request.args["state"]:
        abort(500)  # State does not match!

    credentials = flow.credentials
    request_session = requests.session()
    cached_session = cachecontrol.CacheControl(request_session)
    token_request = google.auth.transport.requests.Request(session=cached_session)

    id_info = id_token.verify_oauth2_token(
        id_token=credentials._id_token,
        request=token_request,
        audience=GOOGLE_CLIENT_ID
    )

    session["google_id"] = id_info.get("sub")  # info we get from user's profile.we could use more api if needed.
    session["name"] = id_info.get("name")
    session['email'] = id_info.get('email')

    email = session['email']

    doc = client.peerReview.instructor.find_one({"email": email})  # find if the email exits in the instructor collection
    doc1 = client.peerReview.student.find_one({"email": email})  # find if the email exits in the student collection

    if doc is not None:  # check if there's any, so the email must from one of the instructor.
        return redirect("/protected_area")
    elif doc1 is not None: # check if there's any, so the email come from one of the student.
        return redirect(('/user_area'))
    else:                 # if the email doesn't belong to either instructor or student, it goes back to login page.
        return redirect('/')


# clear out log session for the users. we can create a logout button link to this if needed.
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# user will login through this page. I have a login button here.
@app.route("/")
def index():
    return "Hello World <a href='/login'><button>Login</button></a> "  # a login button to call "/login"


# pages only be shown after login if the email belongs to instructor.
@app.route("/protected_area")
@login_is_required
def protected_area():
    # email = dict(session).get('email', None)
    return render_template('admin.html')

# pages only be shown after login if the email belongs to students.
@app.route("/user_area/")
@login_is_required
def user_area():
    # email = dict(session).get('email', None)
    return render_template('index.html')



if __name__ == "__main__":
    app.run(debug=True)
