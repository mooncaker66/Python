from flask import Flask
from flask_pymongo import PyMongo
from bson.json_util import dumps
from bson.objectid import ObjectId
from flask import jsonify, request

app = Flask(__name__)
app.secret_key = 'secretkey'

app.config['MONGO_URI'] = "mongodb://localhost:27017/peerReview"

mongo = PyMongo(app)



# create a new review, name = projectName, contents = all the questions, could be subfield.
@app.route('/create', methods=['POST'])
def create():
    _json = request.json
    _name = _json['name']
    _contents = _json['contents']

    if _name and _contents and request.method == 'POST':
        id = mongo.db.reviewQuestion.insert({'name': _name, 'contents': _contents})
        resp = jsonify("New review created successfully")
        resp.status_code = 200
        return resp

    else:
        return not_found()


# find all the exiting project reviews. list the count and name only.
@app.route('/allReviews')
def allReviews():
    reviews = mongo.db.reviewQuestion.find({},{"name": 1})
    resp = dumps(reviews)
    count = mongo.db.reviewQuestion.find().count()
    return "there are " + str(count) + " projects\n"+ resp



# find a specific project review by their name.(by exact name, maybe use fuzzy search if needed)
@app.route("/find/<name>")
def find(name):
    review = mongo.db.reviewQuestion.find_one({'name': name})
    resp = dumps(review)
    return resp

# a fuzzy search that search 'name' that are part or full of the title name, case insensitive.
@app.route("/fuzzy/<name>")
def findFuzz(name):
    review = mongo.db.reviewQuestion.find({ "name": {"$regex": name, "$options": 'si'}})
    resp = dumps(review)
    return resp

# a text search function that will search 'text' in everywhere(incluing title, contents etc)
# then list all the documents who has it.(case insensitive)

# need to create index for 'text' to search
# 1. open terminal, type 1.'pip install mongosh', 2. 'mongosh',
# 3. 'use peerReview' 4. 'db.reviewQuestion.createIndex({ "$**": "text"})'
@app.route("/textSearch/<text>")
def textSearch(text):
    review = mongo.db.reviewQuestion.find({ "$text": {"$search": text}})
    resp = dumps(review)
    return resp

# delete a project by their name.
@app.route('/delete/<name>', methods=['DELETE'])
def delete_review(name):
    mongo.db.reviewQuestion.delete_one({'name': name})
    resp = jsonify("Review deleted successfully")
    resp.status_code = 200
    return resp


# update a project by choosing the name first, then modify the name or contents in the project.
@app.route('/update/<name>', methods=['PUT'])
def update(name):
    _id = id
    _json = request.json
    _name = _json['name']
    _contents = _json['contents']

    if _name and _contents and request.method == 'PUT':
        mongo.db.reviewQuestion.update_one({'name': name}, {'$set': {'name': _name, 'contents': _contents}})
        resp = jsonify('review updated successfully')
        resp.status_code = 200
        return resp
    else:
        return not_found()


@app.errorhandler(404)
def not_found(error=None):
    message = {
        'status': 404,
        'message': "NOT FOUND" + request.url
    }
    resp = jsonify(message)
    resp.status_code = 404
    return resp


if __name__ == '__main__':
    app.run(debug=True)
