import json
import os

from flask import Flask, request, send_from_directory, Response, make_response
from flask import send_file

import roster as roster_loader
import tasks as task_loader
import instructors as admin_loader

app = Flask(__name__)

roster = None
admins = None


def error(err):
    print(err)


def validate_admin_credentials():
    netid = request.args['netid'] if 'netid' in request.args else None
    usfid = request.args['usfid'] if 'usfid' in request.args else None

    if not admins.validate_user(netid, usfid):
        print("  Credentials Failed")
        return False, '', ''
    return True, netid, usfid


def validate_roster_credentials():
    netid = request.args['netid'] if 'netid' in request.args else None
    usfid = request.args['usfid'] if 'usfid' in request.args else None

    if not roster.validate_user(netid, usfid):
        print("  Credentials Failed")
        return False, '', ''
    return True, netid, usfid


@app.route('/')
def send_main():
    try:
        return send_file('static/index.html')
    except Exception as e:
        return str(e)


@app.route('/<path:path>')
def send_very_large(path):
    try:
        return send_from_directory('static', path)
    except Exception as e:
        return str(e)


@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)


@app.route('/submission/<path:path>')
def send_submission(path):
    return send_from_directory('data/submissions', path)


@app.route('/edit_review', methods=['GET', 'POST'])
def edit_review():
    netid = request.args['netid'] if 'netid' in request.args else None
    usfid = request.args['usfid'] if 'usfid' in request.args else None
    taskid = request.args['taskid'] if 'taskid' in request.args else None

    if not roster.validate_user(netid, usfid):
        print("  Credentials Failed")
        return "{}"

    ret_tasks = tasks.get_assigned_tasks(netid)
    for t in filter(lambda t: t['taskid'] == taskid, ret_tasks):
        with open("data/reviews/" + t['taskid'] + ".json", 'w') as outfile:
            json.dump(request.json['review'], outfile)
        t['status'] = request.json['status']
        tasks.save_tasks()
        return "{}"

    print("  Task Not Found")
    return "{}"


@app.route('/get_tasks', methods=['GET', 'POST'])
def get_tasks():
    success, netid, usfid = validate_admin_credentials()
    if success:
        return json.dumps(tasks.tasks)

    success, netid, usfid = validate_roster_credentials()
    if not success:
        print("  Credentials Failed")
        return "[] "

    ret_tasks = tasks.get_assigned_tasks(netid) + tasks.get_my_reviews(netid)
    return json.dumps(ret_tasks)


@app.route('/get_task', methods=['GET', 'POST'])
def get_task():
    taskid = request.args['taskid'] if 'taskid' in request.args else None

    success, netid, usfid = validate_admin_credentials()
    if success:
        ret_tasks = tasks.tasks
        for t in filter(lambda t: t['taskid'] == taskid, ret_tasks):
            return json.dumps(t)
        print("  Task Not Found")
        return "{}"

    success, netid, usfid = validate_roster_credentials()
    if success:
        ret_tasks = tasks.get_assigned_tasks(netid) + tasks.get_my_reviews(netid)
        for t in filter(lambda t: t['taskid'] == taskid, ret_tasks):
            return json.dumps(t)
        print("  Task Not Found")
        return "{}"

    print("  Credentials Failed")
    return "{}"


@app.route('/get_review', methods=['GET', 'POST'])
def get_review():

    taskid = request.args['taskid'] if 'taskid' in request.args else None

    success, netid, usfid = validate_admin_credentials()
    if success:
        ret_tasks = tasks.tasks
    else:
        success, netid, usfid = validate_roster_credentials()
        if success:
            ret_tasks = tasks.get_assigned_tasks(netid) + tasks.get_my_reviews(netid)
        else:
            print("  Credentials Failed")
            return "{}"

    for t in filter(lambda t: t['taskid'] == taskid, ret_tasks):
        print("data/reviews/" + t['taskid'] + ".json")
        if os.path.exists("data/reviews/" + t['taskid'] + ".json"):
            resp = make_response(send_file("data/reviews/" + t['taskid'] + ".json"))
            resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            resp.headers["Pragma"] = "no-cache"
            resp.headers["Expires"] = "0"
            resp.mimetype = "text/json"
            return resp
            #return send_file("data/reviews/" + t['taskid'] + ".json", mimetype="text/json")
        print("  File Not Found")
        return "{}"

    print("  Task Not Found")
    return "{}"


@app.route('/rescan_submissions', methods=['GET', 'POST'])
def rescan_submissions():
    success, netid, usfid = validate_admin_credentials()

    if not success:
        return json.dumps({'status': "Credentials Failed"})

    tasks.scan_project_submissions(roster)
    return json.dumps({'status': "OK", 'projects': list(tasks.submissions.keys())})


@app.route('/clear_tasks', methods=['GET', 'POST'])
def clear_tasks():
    success, netid, usfid = validate_admin_credentials()

    if not success:
        return json.dumps({'status': "Credentials Failed"})

    project = request.args['project'] if 'project' in request.args else None
    if project not in tasks.submissions:
        print("  Project Not Found")
        return json.dumps({'status': "Project Not Found"})

    tasks.clear_tasks(project)
    return json.dumps({'status': "OK"})


@app.route('/assign_tasks', methods=['GET', 'POST'])
def assign_tasks():
    success, netid, usfid = validate_admin_credentials()

    if not success:
        return json.dumps({'status': "Credentials Failed"})

    project = request.args['project'] if 'project' in request.args else None
    if project not in tasks.submissions:
        print("  Project Not Found")
        return json.dumps({'status': "Project Not Found"})

    tasks.assign_tasks(roster,project)
    return json.dumps({'status': "OK"})


if __name__ == '__main__':
    roster = roster_loader.Roster()
    admins = admin_loader.Instructors()
    tasks = task_loader.Tasks()

    app.run(host='0.0.0.0', port=5000)
