import os
import shutil
import random
import string
import json


class Tasks:
    def __init__(self):
        self.submissions = {}
        self.tasks = []
        if os.path.exists('data/tasks.json'):
            with open('data/tasks.json') as json_file:
                self.tasks = json.load(json_file)
        if not os.path.exists('data/reviews'):
            os.mkdir('data/reviews')

    def save_tasks(self):
        with open('data/tasks.json', 'w') as outfile:
            json.dump(self.tasks, outfile, indent=2)

    def scan_project_submissions(self, roster):
        self.submissions = {}
        for project in os.listdir('data/submissions'):
            proj_path = os.path.join('data/submissions', project)
            if os.path.isdir(proj_path):
                self.submissions[project] = {}
                for submission in os.listdir(proj_path):
                    netid = roster.match_submission(submission)
                    if netid is not None:
                        self.submissions[project][netid] = submission

    def clear_tasks(self, project):
        for t in filter(lambda t: t['project'] == project, self.tasks):
            os.remove('data/reviews/' + t['taskid'] + '.json')
        self.tasks = list(filter(lambda t: not t['project'] == project, self.tasks))
        self.save_tasks()

    def assign_tasks(self, roster, project):
        pool = []

        while len(pool) < roster.size() * 3:
            pool.extend(self.submissions[project].keys())

        for netid in roster.list():
            assignments = {}
            while len(assignments) < 3:
                taskid = ''.join(random.choice(string.ascii_lowercase) for i in range(16))
                sel = random.randint(0, len(pool) - 1)
                if pool[sel] == netid: continue
                if pool[sel] in assignments: continue
                assignments[pool[sel]] = {'taskid': taskid,
                                          'reviewer': netid,
                                          'creator': pool[sel],
                                          'project': project,
                                          'submission': self.submissions[project][pool[sel]],
                                          'status': 'todo'}
                del pool[sel]

            for t in assignments.values():
                shutil.copyfile('data/' + project + '.json', 'data/reviews/' + t['taskid'] + '.json')
                self.tasks.append(t)

        self.save_tasks()

    def get_assigned_tasks(self,netid):
        return list(filter(lambda t: t['reviewer'] == netid, self.tasks))

    def get_my_reviews(self,netid):
        return list(filter(lambda t: t['creator'] == netid, self.tasks))
