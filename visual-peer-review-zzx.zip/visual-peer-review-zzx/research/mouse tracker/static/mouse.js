//In the developer view you can obtain the process output
//obtains X and Y coordinates of the mouse pointer on screen

window.addEventListener("mousemove", function (e) {
	document.getElementById("x-value").textContent = e.x;
	document.getElementById("y-value").textContent = e.y;
  });
  
