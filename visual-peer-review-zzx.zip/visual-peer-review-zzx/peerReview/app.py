
from pymongo import MongoClient


# this is simply how I created my mongodb database locally, there is also a cloud version.
# for the peerReview, I added one field called "name" to specify which project, and put all other contents
# under the field "contents". I created manually below to show.

# for student and instructor collection, we can simply import them as json or cvs file, or input manually.
# during my test, I added a field called "email" on both instructor and student collection to test authentication.


cluster = "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false"

client = MongoClient(cluster)

# or your can just do 'client = MongoClient('localhost', 27017)

db = client.peerReview  # create a database

collection = db.student  # create three collections
collection = db.instructor
collection = db.reviewQuestion

# I create few variable that is going to represents project1, project2, student, and instructor.
# after that we can insert these into our collections.

project1 = {
    "name": "project1",
    "contents":[
        {
            "title": "Visualization Narrative",
            "question": [
                {
                    "title": "Choice of Visualization",
                    "description": "Was a good choice of accurate and informative visualization used?",
                    "options": [
                        {
                            "description": "No Description"
                        },
                        {
                            "description": "Incomplete"
                        },
                        {
                            "description": "Complete or Self-Explanatory"
                        }
                    ],
                    "comment":{"text": ""}
                },
                {"title": "Visualization Questions",
                "description": "What 3 questions do you think the visualizations are trying to answer?",
                 "comment":{"text": ""}}
            ]
        },
        {
            "title": "Design Considerations",
            "questions": [{
                "title": "Clear, Detailed, and Thorough Labeling",
                "description": "Is appropriate and complete labeling used throughout or do missing labels require assumptions about the data?",
                "options": [{
                    "description": "No labels"},
                    {
                    "description": "Some Missing labels"},
                    {
                    "description": "Completely labeled"}],
                "comment": {"text": ""}
            },
                {
                "title": "Missing Scales",
                "description": "Are scales provided for the data?",
                "options": [
                    {"description": "No Scales"},
                    {"description": "Some Missing Scales"},
                    {"description": "All Scales Present"}
                ],
                "comment": {"text": ""}
                },
                {
                "title": "Missing Legend",
                "description": "Is a legend provided for the data? Does the legend provide useful information?",
                "options": [
                    {"description": "No Legend"},
                    {"description": "Incomplete Legend"},
                    {"description": "Complete Legend"}],
                "comment": {
                    "text": ""}
                },
                {
                "title": "Data Density",
                "description": "Has too much data been included in the visualization making interpretation difficult? ",
                "options": [
                    {"description": "Too Sparse"},
                    {"description": "Expected"},
                    {"description": "Too Dense"}],
                "comment": {"text": ""}
                }]
        }
    ]
}

project2 = {
    "name": "project2",
    "contents":
[
   {
      "title":"Visualization Narrative",
      "questions":[
         {
            "title":"Choice of Visualization",
            "description":"Was a good choice of accurate and informative visualization used?",
            "options":[
               {"description":"No Description"},
               {"description":"Incomplete"},
                {"description":"Complete or Self-Explanatory"}
            ],
            "comment":{
                "text":""
            }
         }
      ]
   },
   {
      "title":"Design Considerations",
      "questions":[
         {
            "title":"Clear, Detailed, and Thorough Labeling",
            "description":"Is appropriate and complete labeling used throughout or do missing labels require assumptions about the data?",
            "options":[
                {"description":"No labels"},
                {"description":"Some Missing labels"},
                {"description":"Completely labeled"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Missing Scales",
            "description":"Are scales provided for the data?",
            "options":[
                {"description":"No Scales"},
                {"description":"Some Missing Scales"},
                {"description":"All Scales Present"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Missing Legend",
            "description":"Is a legend provided for the data? Does the legend provide useful information?",
            "options":[
                {"description":"No Legend"},
                {"description":"Incomplete Legend"},
                {"description":"Complete Legend"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Scale Distortion",
            "description":"Is any scale distortion or deception used in the visualization?",
            "options":[
                {"description":"Severe Distortion"},
                {"description":"Minor Distortion"},
                {"description":"No Distortion"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Lie Factor",
            "description":"Is there any lie factor? How extreme is the lie factor?",
            "options":[
                {"description":"Major Lie"},
                {"description":"Minor Lie"},
                {"description":"No Lie"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Data/Ink Ratio",
            "description":"Is the data to ink ratio reasonable? Could it be more efficient?",
            "options":[
                {"description":"Way Too Little"},
                {"description":"Slightly Too Little"},
                {"description":"Perfect Amount of Ink"},
                {"description":"Slightly Too Much Ink"},
                {"description":"Way Too Much Ink"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Chart Junk, Embellishments, Aesthetics",
            "description":"Are appropriate embellishments used? Are the embellishments distracting? Do the embellishments add to the visualization?",
            "options":[
                {"description":"Way Too Few"},
                {"description":"A Bit Too Few"},
                {"description":"Perfect Number of Embellishments"},
                {"description":"A Bit Many Embellishments"},
                {"description":"Way Too Many Embellishments"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Data Density",
            "description":"Has too much data been included in the visualization making interpretation difficult? ",
            "options":[
                {"description":"Too Sparse"},
                {"description":"Expected"},
                {"description":"Too Dense"}
            ],
            "comment":{
                "text":""
            }
         },
         {
            "title":"Task Selection",
            "description":"Does the visualization enable appropriate visual analysis tasks for the data type and/or dataset?",
            "options":[
                {"description":"Unclear Task Selection"},
                {"description":"Some Tasks Missing"},
                {"description":"Wide Range of Task Support"}
            ],
            "comment":{
                "text":""
            }
         }
      ]
   }
]


}

instructor1 = {
    "Instructor": "Zhixun Zhao",
    "SIS User ID": "U73074578",
    "SIS Login ID": "zzx",
    "email": "mooncaker6@gmail.com"
}

student1 = {

    "Student": "Adorno Nieves, Julio",
    "ID": "4479065",
    "SIS User ID": "U34617307",
    "SIS Login ID": "jma29",
    "Section": "CAP5745.001S21.26117 Interactive Data Visualization",
    "project2_submission": "Deltafire29",
    "email": "zhixun@mail.usf.edu"
}

students = db.student
instructors = db.instructor
reviews = db.reviewQuestion

#insert into our collections.

students.insert_one(student1)
instructors.insert_one(instructor1)
reviews.insert_one(project1)
reviews.insert_one(project2)

print(client.list_database_names())

print(db.list_collection_names())








