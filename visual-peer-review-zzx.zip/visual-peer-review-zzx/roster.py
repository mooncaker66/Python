import csv
import json


class Roster:
    def __init__(self):
        self.roster = {}
        with open('data/roster.csv', 'r') as csvfile:
            for row in csv.DictReader(csvfile):
                self.roster[row['SIS Login ID']] = \
                    {'name': row['Student'],
                     'id': row['ID'],
                     'usfid': row['SIS User ID'],
                     'netid': row['SIS Login ID'],
                     'section': row['Section'].split('.')[0],
                     'submission': row['Student'].lower().replace(',', '').replace(' ','') + '_' + row['ID']}

    def size(self):
        return len(self.roster)

    def list(self):
        return self.roster.keys()

    def get_user(self, netid):
        return self.roster[netid]

    def validate_user(self, netid, usfid):
        if netid is None or usfid is None: return False
        if netid in self.roster:
            if self.roster[netid]['usfid'] == usfid:
                return True
        return False

    def match_submission(self, submission):
        for netid in self.roster.keys():
            if submission.startswith(self.roster[netid]['submission']):
                return netid
        return None
