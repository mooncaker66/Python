import csv
import json


class Instructors:
    def __init__(self):
        self.instructors = {}
        with open('data/instructors.csv', 'r') as csvfile:
            for row in csv.DictReader(csvfile):
                self.instructors[row['SIS Login ID']] = \
                    {'name': row['Instructor'],
                     'usfid': row['SIS User ID'],
                     'netid': row['SIS Login ID']}

    def size(self):
        return len(self.instructors)

    def list(self):
        return self.instructors.keys()

    def get_user(self, netid):
        return self.instructors[netid]

    def validate_user(self, netid, usfid):
        if netid is None or usfid is None: return False
        if netid in self.instructors:
            if self.instructors[netid]['usfid'] == usfid:
                return True
        return False
